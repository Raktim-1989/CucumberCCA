package stepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.FirefoxBinary;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {
	WebDriver driver;
	String text;
	@Before
	public void setUp(){
		System.setProperty("webdriver.gecko.driver", "/usr/bin/geckodriver");
    	FirefoxBinary firefoxBinary = new FirefoxBinary();
    	firefoxBinary.addCommandLineOptions("--headless");
        FirefoxProfile profile=new FirefoxProfile();
    	FirefoxOptions firefoxOptions = new FirefoxOptions();
    	firefoxOptions.setBinary(firefoxBinary);
    	firefoxOptions.setProfile(profile);
        driver=new FirefoxDriver(firefoxOptions);
	}
	
	@Given("^I have navigated to shipping application home page$")
	public void loadUrl(){
		driver.get("https://webapps.tekstac.com/CostCalculation/");	    
		System.out.println("Application is launched");
	    
	}
	
	@When("^I enter \"(.*)\" and select \"(.*)\" Transport mode$")
	public void testCalculateCost(String weight, String transportmode){
	  //Please fill the required codes
	  driver.findElement(By.id("weight")).sendKeys(weight);
	  driver.findElement(By.id(transportmode)).click();
	  driver.findElement(By.id("premium")).click();
	  driver.findElement(By.id("calculate")).click();
	}

	
	@Then("^I validate the message with total shipping cost$")
	public void validateResult(){
		//Please fill the required codes
		text=driver.findElement(By.id("result")).getText();
	}
	
	@After
	public void tearDown(){
		driver.quit();
	}
}
